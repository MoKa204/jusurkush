document.addEventListener('DOMContentLoaded', () => {
  // Mobile navigation toggle (if needed later)
  const navIcon = document.querySelector('.nav-icon');
  if (navIcon) {
    navIcon.addEventListener('click', (e) => {
      // Add behavior if mobile menu is implemented
    });
  }

  // Add smooth scrolling to all links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        e.preventDefault();
        targetElement.scrollIntoView({
          behavior: 'smooth'
        });
      }
    });
  });

  // Basic Wishlist button toggle for non-WooCommerce static elements
  const wishlistButtons = document.querySelectorAll('.product-wishlist');
  wishlistButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      btn.style.color = btn.style.color === 'red' ? '' : 'red';
      btn.innerHTML = btn.style.color === 'red' ? '♥' : '♡';
    });
  });
});
